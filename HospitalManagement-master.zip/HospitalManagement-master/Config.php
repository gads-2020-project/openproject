<?php
$server='localhost';
$username='root';
$password='';
$db='hospitaldb';

$conn = new mysqli ($server,$username,$password,$db);

?>