# HOSPITAL MANAGEMENT 
This is a web hospial management app 
This is my project and it is not realated to any hospital at all
 