function openform(argument) {
	// body...
	document.getElementById("my-form").style.display="block";
	
}
function closeform(){
	document.getElementById("my-form").style.display="none";
	
}
function openbooking(argument) {

	// body...
	document.getElementById("my-booking").style.display="block";
}
function closebooking(argument) {
	// body...
	document.getElementById("my-booking").style.display="none";
}
function openbookingdetails(argument) {
	// body...
	document.getElementById("my-bookings").style.display="block";
}
function closebookingdetails(argument) {
	// body...
	document.getElementById("my-bookings").style.display="none";
}
function openmedication(argument) {
	// body...
	document.getElementById("my-medication").style.display="block";
}
function closemedication(argument) {
	// body...
	document.getElementById("my-medication").style.display="none";
}
function opensignup(argument) {
	// body...
	document.getElementById("my-signup").style.display="block";
}
function closesignup(argument) {
	// body...
	document.getElementById("my-signup").style.display="none";
}
function randomNogenerator(argument) {
	// body...

	document.getElementById("patientNolabel").innerHTML = Math.floor(Math.random() * 10000);
}
function openformxray(argument) {
	// body...
	document.getElementById("doctorXray").style.display="block";
	
}
function closeformxray(){
	document.getElementById("doctorXray").style.display="none";
	
}
function openformtherapy(argument) {
	// body...
	document.getElementById("doctortherapy").style.display="block";
	
}
function closeformtherapy(){
	document.getElementById("doctortherapy").style.display="none";
	
}

function openformct(argument) {
	// body...
	document.getElementById("doctortherapy").style.display="block";
	
}
function closeformct(){
	document.getElementById("doctortherapy").style.display="none";
	
}









