<!DOCTYPE html>
<html>
<head>
	<title>Big hospital Nurses</title>
	<link rel="stylesheet" type="text/css" href="Styles3.css">
</head>
<body>
	<div class="container">
		<div class="menubar">
			<ul>
			<li><a href=""><img src="icons\images (2).png " height="40px" style="margin-right: 5px; margin-top: -16px;"></a>
				<div class="submenu">
				<ul>
					<li><a href="Profilenurse.php">Profile</a></li>
					<li><a href="Home.php">Logout</a></li>
				</ul></div>
			</li>

			</ul>
		</div>
		<div class="leftdiv"> 
			<center>
			<img src="icons/helth.png" height="60px" style="padding-top: 8px;">
			</center>
			<div>

				<input type="button" name="" value="My patient" id="nursemenu">

			</div>
			<div>
				<input type="button" name="" value="Words" id="nursemenu">
			</div>
			<div>
				<input type="button" name="" value="Care Unit" id="nursemenu">
			</div>
			<div>
				<input type="button" name="" value="Labs" id="nursemenu">
			</div>
			<div>
				<a href="Profilenurse.php"><button id="nursemenu">Profile</button></a>
			</div>
		</div>
		<div class="maindiv"> No activity allowed <br>
			<p>view your profile in profile tab and make any changes if needed Thank you</p>
		</div>
		<div class="footer"> 
			<center>&copy;2020 &nbsp;&trade;BigHosp<br>
			<i>thank you for being with us </i>
		</div>

</div>

</body>
</html>